package com.Upload_Download_de_Arquivo;

import java.io.File;
import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.Part;

/**
 * Servlet implementation class UploadDeArquivo
 */
@WebServlet("/UploadDeArquivo")
@MultipartConfig
public class UploadDeArquivo extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public UploadDeArquivo() {
        super();
        
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	/**
	 *
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		
		String msg="Arquivo Enviado";
		String path ="C:/Backup Maquina";
		try	{
			
			for(Part part : request.getParts()) {
				if(part.getName().equals("file"))
					part.write(path+File.separator+part.getSubmittedFileName());
				
			}
			
		}	catch (Exception e) {
			
			System.out.println(e.getMessage());
			msg = "Erro ao Salvar";

		}
		request.setAttribute("msg",msg);
		request.getRequestDispatcher("index.jsp").forward(request, response);
	}
}